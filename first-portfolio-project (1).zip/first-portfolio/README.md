# Personal Portfolio — First Project

A responsive personal portfolio website for an AI & Machine Learning student interested in game development and creative technology.

## Built with
- HTML5
- CSS3
- Vanilla JavaScript

## Run locally
1. Download or clone this repository.
2. Open `index.html` in your browser.

No build tools or dependencies are required.

## Personalize before publishing
Search the project for these placeholders and replace them:
- `[Your Name]` — your preferred display name.
- `your.email@example.com` — your contact email.
- `https://www.linkedin.com/` — your LinkedIn profile URL.
- `https://github.com/` — your GitHub profile URL.

You can also update the About section and add your future projects as you build them.

## Deploy with GitHub Pages
1. Open the repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish your site.

## License
You may use and customize this project for your personal portfolio.
